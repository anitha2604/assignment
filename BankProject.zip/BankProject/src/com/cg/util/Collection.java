package com.cg.util;

import java.util.HashMap;

import com.cg.entity.Account;

public class Collection {

	static HashMap<Integer, Account> hs=null;
	static {
		hs=new HashMap<Integer, Account>();
		hs.put(1610, new Account("Anitha", "MIPL", "9652691840", 65000.00));
		hs.put(1127, new Account("Veeresh", "MIPL", "9912460296", 39000.00));
		hs.put(6990, new Account("Cherry", "SIPCOT", "9505553292", 45500.00));
		hs.put(5421, new Account("Jambo", "MIPL", "9789745861",75000.00));
		hs.put(2351, new Account("Pavi", "Mindspace", "9502447891",40000.00));
		
	}
	public static void addcustomer(Integer no,Account a)
	{
		hs.put(no, a); 
	}
	
	public static void  deleteCustomer(int accNo)
	{
		hs.remove(accNo);
	}
	
	public static Account showbalance(int acc)
	{
		if(hs.containsKey(acc))
		{
			Account a=hs.get(acc);
			return a;
		}
		else
			return null;
	}
	
}
