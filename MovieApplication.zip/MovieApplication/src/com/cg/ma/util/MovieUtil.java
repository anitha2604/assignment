package com.cg.ma.util;

import java.util.ArrayList;
import java.util.List;

import com.cg.ma.dto.Movie;



public class MovieUtil {
	private static List<Movie> list = new ArrayList<>();
	
	static{
		list.add(new Movie("AvengersEndgame",200,"2:30",23));
		list.add(new Movie("Kanchana_1",100,"2:30",23));
		list.add(new Movie("Kanchana_2",150,"2:30",23));
		list.add(new Movie("Yevadu",100,"2:30",23));
		list.add(new Movie("Kanchana_3",200,"2:30",23));
	}

	public static List<Movie> getList() {
		return list;
	}

	public static void setList(List<Movie> list) {
		MovieUtil.list = list;
	}
	
}
