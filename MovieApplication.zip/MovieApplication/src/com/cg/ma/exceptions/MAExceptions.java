package com.cg.ma.exceptions;

public class MAExceptions extends Exception {
	public MAExceptions(String message) {
		// TODO Auto-generated constructor stub
		super(message);
		
	}

}
