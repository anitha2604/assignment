package com.cg.ma.dao;

import java.util.List;

import com.cg.ma.dto.Movie;
import com.cg.ma.exceptions.MAExceptions;


public interface MADao {
	int bookMovie(Movie movie) throws MAExceptions;

	List<Movie> getAllShows() throws MAExceptions;

	Movie searchMovie(String movieName) throws MAExceptions;
}
