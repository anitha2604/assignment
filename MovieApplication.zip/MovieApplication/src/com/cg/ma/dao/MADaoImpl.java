package com.cg.ma.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.ma.dto.Movie;
import com.cg.ma.exceptions.MAExceptions;
import com.cg.ma.util.MovieUtil;


public class MADaoImpl implements MADao{

	@Override
	public int bookMovie(Movie movie) throws MAExceptions {
		// TODO Auto-generated method stub
		int sNo = (int) (Math.random() * 1000);
		movie.setSeatNo(sNo);
		List<Movie> show = MovieUtil.getList();
		show.add(movie);
		return sNo;
	}

	@Override
	public List<Movie> getAllShows() throws MAExceptions {
		// TODO Auto-generated method stub
		return MovieUtil.getList();
	}

	@Override
	public Movie searchMovie(String movieName) throws MAExceptions {
		// TODO Auto-generated method stub
		
		List<Movie> list = MovieUtil.getList();
		Movie m = null;
		boolean flag = false;
		
		for(Movie movie : list){
			if(movie.getMovieName().equals(movieName)){
				m = movie;
				flag = true;
				break;
			}
		}
			if (flag == false) {
				throw new MAExceptions("No movie avaliable");
			}

			return m;
		}
		
}
