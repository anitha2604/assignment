package com.cg.ma.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.ma.dao.MADaoImpl;
import com.cg.ma.dto.Movie;
import com.cg.ma.exceptions.MAExceptions;
import com.cg.ma.util.MovieUtil;


public class MAServiceImpl implements MAService  {

	MADaoImpl dao = new MADaoImpl();
	
	@Override
	public int bookMovie(Movie movie) throws MAExceptions {
		// TODO Auto-generated method stub
		return dao.bookMovie(movie);
	}

	@Override
	public List<Movie> getAllShows() throws MAExceptions {
		// TODO Auto-generated method stub
		return dao.getAllShows();
	}

	@Override
	public Movie searchMovie(String movieName) throws MAExceptions {
		// TODO Auto-generated method stub
		return dao.searchMovie(movieName);
	}

	@Override
	public void validateName(String movieName) throws MAExceptions {
		// TODO Auto-generated method stub
		
		String nameRegEx = "[A-Z]{1}[a-zA-Z]{4,9}";
		if (!Pattern.matches(nameRegEx, movieName)) {
			throw new MAExceptions("first letter should be capital and length must be in between 5 to 10");
		}
		
	}

	@Override
	public void validateCost(double movieCost) throws MAExceptions {
		// TODO Auto-generated method stub
		if (movieCost == 100 || movieCost == 150 || movieCost == 200 ) {
			System.out.println("Booked movie");
			
		}else{
			throw new MAExceptions("cost should be 100/150/200");
		}
	}

}
