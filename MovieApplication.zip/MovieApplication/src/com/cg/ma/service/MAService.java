package com.cg.ma.service;

import java.util.List;

import com.cg.ma.dto.Movie;
import com.cg.ma.exceptions.MAExceptions;


public interface MAService {
	
	int bookMovie(Movie movie) throws MAExceptions;

	List<Movie> getAllShows() throws MAExceptions;

	Movie searchMovie(String movieName) throws MAExceptions;
	
	public void validateName(String movieName) throws MAExceptions;

	public void validateCost(double movieCost) throws MAExceptions;

}
