package com.cg.ma.dto;

public class Movie {
	private String movieName;
	private int movieCost;
	private String time;
	private int seatNo;
	private int noOfTickets;
	
	public Movie() {
		// TODO Auto-generated constructor stub
	}
	
	
	public Movie(String movieName, int movieCost, int noOfTickets) {
		super();
		this.movieName = movieName;
		this.movieCost = movieCost;
		this.noOfTickets = noOfTickets;
	}


	public Movie(String movieName, int movieCost, String time, int noOfTickets) {
		super();
		this.movieName = movieName;
		this.movieCost = movieCost;
		this.time = time;
		this.noOfTickets = noOfTickets;
	}


	public Movie(String movieName, int movieCost, String time, int seatNo, int noOfTickets) {
		super();
		this.movieName = movieName;
		this.movieCost = movieCost;
		this.time = time;
		this.seatNo = seatNo;
		this.noOfTickets = noOfTickets;
	}

	public Movie(String movieName, int movieCost, int seatNo, int noOfTickets) {
		super();
		this.movieName = movieName;
		this.movieCost = movieCost;
		this.seatNo = seatNo;
		this.noOfTickets = noOfTickets;
	}

	public int getNoOfTickets() {
		return noOfTickets;
	}

	public void setNoOfTickets(int noOfTickets) {
		this.noOfTickets = noOfTickets;
	}

	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public int getMovieCost() {
		return movieCost;
	}
	public void setMovieCost(int movieCost) {
		this.movieCost = movieCost;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getSeatNo() {
		return seatNo;
	}
	public void setSeatNo(int seatNo) {
		this.seatNo = seatNo;
	}
@Override
public String toString() {
	// TODO Auto-generated method stub
	return "Movie [movieName=" + movieName + ", time=" + time
			+ ", movieCost=" + movieCost + ", noOfTickets="+noOfTickets+"]";
}

}
