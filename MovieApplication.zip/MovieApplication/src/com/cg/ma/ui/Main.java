package com.cg.ma.ui;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import com.cg.ma.dto.Movie;
import com.cg.ma.exceptions.MAExceptions;
import com.cg.ma.service.MAServiceImpl;
public class Main {
	
	public static void main(String args[]){
		
		Scanner scan = null;
		MAServiceImpl service = new MAServiceImpl();
		String continueChoice = "";
		
		do {

			System.out.println("****** Movie Applictaion ******");
			System.out.println("1.Book Movie");
			System.out.println("2.Search Movie");
			System.out.println("3.Display All Shows");
			System.out.println("4.Exit");

			int choice = 0;
			boolean choiceFlag = false;
			
			do {
				scan = new Scanner(System.in);
				System.out.println("Enter your choice");
				try {
					choice = scan.nextInt();
					choiceFlag = true;

					switch (choice) {
			
					case 1:
						
						String movieName = "";
						boolean movieNameFlag = false;
						
						do{
							scan = new Scanner(System.in);
							System.out.println("Enter movie name");
							try{
							movieName = scan.nextLine();
							service.searchMovie(movieName);
							movieNameFlag = true;
							break;
							}catch(MAExceptions e){
								movieNameFlag = false;
								System.err.println(e.getMessage());
							}
						}while(!movieNameFlag);
			
						int movieCost = 0;
						boolean movieCostFlag = false;
						do {
							scan = new Scanner(System.in);
							System.out.println("Enter Movie Cost:");
							try {
								movieCost = scan.nextInt();
								service.validateCost(movieCost);
								movieCostFlag = true;
								break;
							} catch (InputMismatchException e) {
								movieCostFlag = false;
								System.err.println("Cost should be digits");
							} catch (MAExceptions e) {
								movieCostFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!movieCostFlag);
						scan = new Scanner(System.in);
						System.out.println("enter noOfTickets");
						int noOfTickets = scan.nextInt();
						
						Movie movie = new Movie(movieName, movieCost, noOfTickets);
						try {
							int generatedSeatNo = service.bookMovie(movie);
							System.out.println("Movie booked with the seatNo: " + generatedSeatNo);
						} catch (MAExceptions e) {
							System.out.println(e.getMessage());
						}

						break;
					case 2:
						String mName = null;
						boolean mNameFalg = false;
						do {
							scan = new Scanner(System.in);
							System.out.println("Enter Movie Name:");
							try {
								mName = scan.next();
								mNameFalg = true;
								Movie mData;
								try {
									mData = service.searchMovie(mName);
									System.out.println(mData);
								} catch (MAExceptions e1) {
									System.err.println(e1.getMessage());
								}

							} catch (InputMismatchException e) {
								mNameFalg = false;
								System.err.println("Id should be digits");
							}
						} while (!mNameFalg);

						break;
						
					case 3:

						List<Movie> shows = null;
						try {
							shows = service.getAllShows();
							for (Movie out : shows) {
								System.out.println(out);
							}
						} catch (MAExceptions e) {
							System.err.println(e.getMessage());
						}
						break;
					}						

				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("please enter only digits");
				}

			break;
			
			
			}
				
			while (!choiceFlag);

			scan = new Scanner(System.in);
			System.out.println("do you want to continue again [yes/no]");
			continueChoice = scan.nextLine();

		} while (continueChoice.equalsIgnoreCase("yes"));
		scan.close();
	}
}