package com.cg.entity;

public class Account {

	private String CustName;
	private String Branch;
	private String Mob;
	private double Balance;
	public Account(String custName, String branch, String mob, double balance) {
		super();
		CustName = custName;
		Branch = branch;
		Mob = mob;
		Balance = balance;
	}
	public String getCustomerName() {
		return CustName;
	}
	public void setCustomerName(String customerName) {
		CustName = customerName;
	}
	public String getBranch() {
		return Branch;
	}
	public void setBranch(String branch) {
		Branch = branch;
	}
	public String getMob() {
		return Mob;
	}
	public void setMob(String mobno) {
		Mob = mobno;
	}
	public double getBalance() {
		return Balance;
	}
	public double setBalance(double balance) {
		return Balance = balance;
	}
	@Override
	public String toString() {
		return "Account [CustomerName=" + CustName + ", Branch=" + Branch + ", Mobno=" + Mob + ", Balance="
				+ Balance + "]";
	}
	
	
	
}
