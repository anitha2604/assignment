package com.cg.DAO;

import com.cg.entity.Account;

public interface AccountDAO {

	public int addcustomer(Integer no,Account a);
	
	public Account showbalance(int acc);
	
}
