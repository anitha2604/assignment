package com.cg.DAO;

import com.cg.entity.Account;
import com.cg.util.Collection;

public class AccountDAOImpl implements AccountDAO {

	
	@Override
	public int addcustomer(Integer no,Account a) {
		Collection.addcustomer(no,a);
		return 0;
	}
	
	@Override
	public Account showbalance(int acc) {
		Account a=Collection.showbalance(acc);
		return a;
	}
	
}
