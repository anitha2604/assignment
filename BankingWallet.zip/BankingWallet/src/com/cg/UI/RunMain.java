package com.cg.UI;

import java.util.Random;
import java.util.Scanner;

import com.cg.Exception.InvalidDataException;
import com.cg.Service.AccountService;
import com.cg.Service.AccountServiceImpl;
import com.cg.entity.Account;
public class RunMain {

		static Scanner sc=null;
		static AccountService acc=null;
		
		public static void main(String[] args) {
		sc=new Scanner(System.in);
		acc=new AccountServiceImpl();
		while(true)
		{
		
		
		System.out.println("Welcome to ICIC Bank");
		
		System.out.print("1. Create Account");
		System.out.println("2. Show Balance ");
		System.out.print("3. Deposit");
		System.out.println("4. Withdrawal");
		System.out.print("5. Fund Transfer");
		System.out.println("6. Print Transaction");
		System.out.println("Your Choice: ");
		int a=0;
		a=sc.nextInt();
		
		switch(a)
		{
		case 1:
			addcustomer();
			break;
		case 2:
			showbalance();
			break;
		case 3:
			deposit();	
			break;
		case 4:
			withdraw();
			break;
		case 5:
			fundtransfer();
			break;
		/*case 6:
			
			break;*/
		default:
			System.out.println("Please select options");
			}	
		}
	}
		
		
	public static void addcustomer()
	{
		Random ran=new Random();
		int accno=ran.nextInt(2000);
		System.out.println("Enter Customer Name");
		String name=sc.next();
		boolean resName=acc.validateCustomerName(name);
		try
		{
			if(resName==false)
			{
				throw new InvalidDataException("Invalid name.Try again!");
			}
			else 
			{
				System.out.println("Your name is valid name...");
			}
			{
				System.out.println("Enter Branch");
				String branch=sc.next();
				boolean resBranch=acc.ValidateBranch(branch);
				try
				{	
					if(resBranch==false)
					{
						throw new InvalidDataException("Invalid branch.Try again!");
					}
					else 
					{
						System.out.println("Your branch is valid branch...");
					}
						{
							System.out.println("Enter Mobile No");
							String mobile=sc.next();
							boolean resMob=acc.ValidateCustomerMobileno(mobile);
							try
							{
								if(resMob==false)
								{
									throw new InvalidDataException("Invalid number.Try again!");
								}
								else 
								{
									System.out.println("Valid mobiile number...");
								}	
									{
										System.out.println("Enter Account Balance");
										Double balance=sc.nextDouble();
										Account a=new Account(name, branch, mobile, balance);
										acc.addcustomer(accno,a);
										
										System.out.println("CREATED Successfully");
										System.out.println("Name: " +name);
										System.out.println("Branch: "+branch);
										System.out.println("Mobile No: "+mobile);
										System.out.println("Account number: " +accno);
									}
							}
							catch(Exception e)
							{
								System.out.println("Enter the Valid Name: "+e);
							}
						}
				}	
				catch (Exception e)
				{
					System.out.println("Enter the Valid Branch: "+e);	
				}			
			}	
		}
		catch (Exception e)
		{
			System.out.println("Enter the Valid Mobile No: "+e);
		}
	}
	
	
	public static void showbalance() 
	{	
		System.out.println("Enter the Account Number: ");
		int account=sc.nextInt();
		Account a=acc.showbalance(account);
		System.out.println(a.getCustomerName()+ " Your Account Balance is: "+a.getBalance());
	}
		
	
	public static void deposit()
	{
		System.out.println("Enter your Account Number: ");
		int account=sc.nextInt();
		
		Account a=acc.showbalance(account);
		double d=a.getBalance();
		
		System.out.println("Enter the amount to be deposited: ");
		double amt=sc.nextDouble();
		
		double res=a.setBalance(d+amt);
		System.out.println(res);	
	}
		
	public static void withdraw()
	{
		System.out.println("Enter your Account Number: ");
		int account=sc.nextInt();
		
		Account a=acc.showbalance(account);
		double d=a.getBalance();
		
		System.out.println(d);
		System.out.println("Enter the amount to be withdrawn: ");
		double wa=sc.nextDouble();
		
		if(d>wa)
		{
			double res=a.setBalance(d-wa);
			System.out.println(res);
		}
		else 
		{
			System.out.println("Insufficient Balance to withdraw! Please withdraw from available balance.");
		}
	}
	
	
	public static void fundtransfer()
		{
		System.out.println("Enter the Account Number to transfer the fund: ");
		int acc1=sc.nextInt();
		Account a1=acc.showbalance(acc1);
		
		System.out.println(a1.getBalance());
		System.out.println("Enter The Amount");
		
		double w=sc.nextDouble();
		double res=(a1.getBalance())-w;
		System.out.println("Amount has been debited: "+res);
		
		
		System.out.println("Enter the Account Number to receive the fund");
		int acc2=sc.nextInt();
		Account a2=acc.showbalance(acc2);
		
		System.out.println(a2.getBalance());
		double res2=(a2.getBalance())+w;
		
		System.out.println("Amount has been credited:" +res2);
		}
	
}
