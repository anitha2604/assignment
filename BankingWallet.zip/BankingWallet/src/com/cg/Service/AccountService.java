package com.cg.Service;

import com.cg.entity.Account;

public interface AccountService {

	public int addcustomer(Integer no,Account a);
	
	public Account showbalance(int acc);
	
	public boolean validateCustomerName(String name);
	
	public boolean ValidateCustomerMobileno(String cid);
	
	public boolean ValidateBranch(String name);
	
}
