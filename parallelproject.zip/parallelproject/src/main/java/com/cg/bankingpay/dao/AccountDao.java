package com.cg.bankingpay.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.bankingpay.bean.ExtAccount;
import com.cg.bankingpay.bean.NewAccount;

public class AccountDao {
static 	Map<Double,NewAccount>account1=new HashMap<Double,NewAccount>();
		Map<Double,ExtAccount>extaccount1=new HashMap<Double,ExtAccount>();
	
		public void addHistory(ExtAccount extaccount) {
		extaccount1.put(extaccount.getAccount_Number(),extaccount);
		}
	public Map<Double, NewAccount> displayAccountDetails() {
		return account1;
	}
	public void addNewAccount(NewAccount account) {
		 account1.put(account.getAccount_Number(),account);
	}

	public int deposit(int account_Number,int amount) {
		int amountAfterDeposit=0;
		for(NewAccount o:account1.values()) {
			System.out.println("account number:  "+ o.getAccount_Number());
			if(o.getAccount_Number()==account_Number) {
				amountAfterDeposit=o.getBalance()+amount;
				o.setBalance(amountAfterDeposit);
				break;
			}
			else{
				System.out.println("Enter Proper Account Number..");
				
			}
		}
		return amountAfterDeposit;
	}

	public int withdraw(int account_Number_check1, int amountWithdrawal) {
		int amountAfterWithdraw=0;
		for(NewAccount o:account1.values()) {
			if(o.getAccount_Number()==account_Number_check1) {
				 amountAfterWithdraw=o.getBalance()-amountWithdrawal;
				o.setBalance( amountAfterWithdraw);
				break;
			}
			else{
				System.out.println("Enter Proper Account Number..");
			}
		}
		return amountAfterWithdraw;
	}

	public int getCurrentBalance(int account_Number_Check2) {
		int displayBalance=0;
		for(NewAccount o:account1.values()) {
			if(o.getAccount_Number()==account_Number_Check2) {
				 displayBalance=o.getBalance();
				break;
			}
			else{
				System.out.println("Enter Proper Account Number..");
				break;
			}
		}
		return displayBalance;
	}

	public String fundTransfer(int account_number, int reciever_account_number,int amountToTransfer) {
		int amountAfterWithdraw=0;
		int amountAfterDeposit=0;
		for(NewAccount o:account1.values()) {
			if(o.getAccount_Number()==account_number) {
				 amountAfterWithdraw=o.getBalance()-amountToTransfer;
				o.setBalance( amountAfterWithdraw);
				break;
			}
			else{
				System.out.println("Enter Proper Account Number..");
				
			}
		}
		for(NewAccount o:account1.values()) {
			if(o.getAccount_Number()==reciever_account_number) {
				amountAfterDeposit = o.getBalance()+amountToTransfer;
				o.setBalance(amountAfterDeposit);
				break;
			}
			else {
				System.out.println("Enter Proper Account Number");
			}
		}
		return "Transfered";
	}
}

