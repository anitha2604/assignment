package com.cg.bankingpay.service;

import java.util.Map;


import com.cg.bankingpay.bean.NewAccount;

public interface AccountServiceInterface {
	Map<Double,NewAccount>displayAccountDetails();
	public void addNewAccount(NewAccount account) ;
}
