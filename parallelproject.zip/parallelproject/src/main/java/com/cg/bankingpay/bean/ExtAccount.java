package com.cg.bankingpay.bean;

import java.time.LocalDateTime;

public class ExtAccount {
	double account_Number;
	String account_HolderName;
	int balance;
	int deposit_amount;
	LocalDateTime date;
	LocalDateTime DepositDate;
	public LocalDateTime getDepositDate() {
		return DepositDate;
	}
	public void setDepositDate(LocalDateTime depositDate) {
		DepositDate = depositDate;
	}
	
	public double getAccount_Number() {
		return account_Number;
	}
	public void setAccount_Number(double account_Number) {
		this.account_Number = account_Number;
	}
	public String getAccount_HolderName() {
		return account_HolderName;
	}
	public void setAccount_HolderName(String account_HolderName) {
		this.account_HolderName = account_HolderName;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public int getDeposit_amount() {
		return deposit_amount;
	}
	public void setDeposit_amount(int deposit_amount) {
		this.deposit_amount = deposit_amount;
	}
	public LocalDateTime getDate() {
		return date;
	}
	public void setDate(LocalDateTime date) {
		this.date = date;
	}	
}
