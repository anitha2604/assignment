package com.cg.bankingpay.ui;

import java.time.LocalDateTime;
import java.util.Scanner;

import com.cg.bankingpay.bean.ExtAccount;
import com.cg.bankingpay.bean.NewAccount;
import com.cg.bankingpay.service.AccountService;

public class Main {

	public static void main(String[] args) {
		AccountService as=new AccountService();
		int i;
		Scanner sc=new Scanner(System.in);
		while(true) {
		System.out.println("Enter Your Choice: \n1.Create New Account\n2.Deposit Amount\n3.Withdrawal Amount\n4.Display\n5.Get Balance\n6.Fund Transfer");
		int choice=sc.nextInt();
		switch(choice){
		case 1:{
			//Creating of New Account
			System.out.println("How many Account do you want to add..??");
			int num_of_account=sc.nextInt();
			int account_number=98765;
			NewAccount []account=new NewAccount[num_of_account];
			ExtAccount e[]=new ExtAccount[num_of_account];
			for(i=0;i<num_of_account;i++)
				e[i]=new ExtAccount();
			for(i=0;i<num_of_account;i++) {
				account[i]=new NewAccount();
				account_number++;
				System.out.println("Add the following Account Detail for creating of new Account....");
				account[i].setAccount_Number(account_number);
				e[i].setAccount_Number(account_number);
				System.out.println("Enter Account Holder Name: ");
				String account_HolderName=sc.next();
				account[i].setAccount_HolderName(account_HolderName);
				e[i].setAccount_HolderName(account_HolderName);
				System.out.println("Enter five digit Phone Number: ");
				int phone_Number=sc.nextInt();
				account[i].setPhone_Number(phone_Number);
				System.out.println("Enter five digit Aadhar Number: ");
				int aadhar_Number=sc.nextInt();
				account[i].setAadhar_number(aadhar_Number);
				System.out.println("your account number is: "+account_number);
				LocalDateTime now=LocalDateTime.now();
				e[i].setDate(now);
				as.addNewAccount(account[i]);
				}
			break;
			}
		case 2:{
			//For Deposit
			System.out.println("You want to deposit amount in your account...\nEnter Account Number..");
			int account_Number_check=sc.nextInt();
			System.out.println("Now enter the amount for deposit");
			int amount=sc.nextInt();
			int amountAfterDeposit=as.deposit(account_Number_check,amount);
			System.out.println("New Balance: "+amountAfterDeposit);
			break;
			}
		case 3:{
			//For Withdrawal
			System.out.println("You want to withdraw amount in your account...\nEnter Account Number..");
			int account_Number_check1=sc.nextInt();
			System.out.println("Now enter the amount for Withdrawal");
			int amountWithdrawal=sc.nextInt();
			int amountAfterWithdraw=as.withdraw(account_Number_check1,amountWithdrawal);
			System.out.println("New Balance: "+amountAfterWithdraw);
			break;
			}
		case 4:{
			//For Display
			System.out.println("Accounts Detail: ");
			System.out.println(as.displayAccountDetails());
			break;
			}
		case 5:{
			//Get balance
			System.out.println("Enter your Account Number: ");
			int account_Number_Check=sc.nextInt();
			int balance=as.getCurrentBalance(account_Number_Check);
			System.out.println("Current Balance: "+balance);
			break;
			}
		case 6:{
			//Fund Transfer
			int account_number,reciever_account_number,amount;
			System.out.println("Enter Account Number: ");
			account_number=sc.nextInt();
			System.out.println("Enter Receiver Account Number: ");
			reciever_account_number=sc.nextInt();
			System.out.println("Enter Amount to Transfer: ");
			amount=sc.nextInt();
			String str=as.fundTransfer(account_number,reciever_account_number,amount);
			System.out.println(str);
			break;
			}
		//case 7:{
			//	Print Transaction
				//System.out.println("Enter The account Number For Print Transaction....");
					//int account_number=sc.nextInt();
					
				//}
		  }
		}
	}
}
