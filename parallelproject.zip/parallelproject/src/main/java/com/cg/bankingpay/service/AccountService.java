package com.cg.bankingpay.service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import com.cg.bankingpay.bean.ExtAccount;
import com.cg.bankingpay.bean.NewAccount;
import com.cg.bankingpay.dao.AccountDao;

public class AccountService implements AccountServiceInterface {
	AccountDao dao=new AccountDao();
	LocalDateTime n=LocalDateTime.now();
	Map<Double,NewAccount>account=new HashMap<Double,NewAccount>();
	Map<LocalDateTime,ExtAccount>history1=new HashMap<LocalDateTime,ExtAccount>();
	
	public Map<Double, NewAccount> displayAccountDetails() {
		account=dao.displayAccountDetails();
		return account;
	}
	public void addNewAccount(NewAccount account) {
		dao.addNewAccount(account);
	}
	public int deposit(int account_number,int amount) {
		int amountAfterDeposit=dao.deposit(account_number,amount);
		return amountAfterDeposit;
	}
	public int withdraw(int account_Number_check1, int amountWithdrawal) {
		int amountAfterWithdrawal=dao.withdraw(account_Number_check1,amountWithdrawal);
		return amountAfterWithdrawal;
	}
	public int getCurrentBalance(int account_Number_Check) {
		return dao.getCurrentBalance(account_Number_Check);
	}
	public String fundTransfer(int account_number, int reciever_account_number,int amount) {
		String str1=dao.fundTransfer(account_number,reciever_account_number,amount);
		return str1;
	}
}
