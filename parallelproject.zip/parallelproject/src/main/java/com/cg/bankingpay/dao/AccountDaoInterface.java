package com.cg.bankingpay.dao;

import java.util.Map;


import com.cg.bankingpay.bean.NewAccount;

public interface AccountDaoInterface {
	public Map<Double, NewAccount> displayAccountDetails();
	public void addNewAccount(NewAccount account);
}
