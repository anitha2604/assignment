package com.cg.DAO;

import javax.persistence.EntityManager;
import com.cg.Entity.Account;
import com.cg.Util.Jpa;

public class AccountDAOImpl implements AccountDAO {

	@Override
	public int addcustomer(Account a)  {
		EntityManager em=Jpa.connnect();
		em.getTransaction().begin();
		em.persist(a);
		em.getTransaction().commit();
		em.close();
		return 0;	
	}

	@Override
	public Account showbalance(int acc) {
		EntityManager em=Jpa.connnect();
		System.out.println("WELCOME ");
		
		em.getTransaction().begin();
		System.out.println("Starting...");
		Account a=em.find(Account.class, acc);
		
		System.out.println(a.getBalance());
		System.out.println("Completed!");
		
		em.getTransaction().commit();
		em.close();
		return a;
	}

	@Override
	public void deposit(double amt, int acc)  {
		EntityManager em=Jpa.connnect();
		
		em.getTransaction().begin();
		Account deposit=em.find(Account.class, acc);
		deposit.setBalance(amt);
		
		em.getTransaction().commit();
		em.close();
	}

	@Override
	public void withdraw(double res, int acc)  {
		EntityManager em=Jpa.connnect();
		
		em.getTransaction().begin();
		Account withdraw=em.find(Account.class, acc);
		withdraw.setBalance(res);
		
		em.getTransaction().commit();
		em.close();
	}

}
