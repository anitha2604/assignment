package com.cg.DAO;

import com.cg.Entity.Account;

public interface AccountDAO {

	public int addcustomer(Account a) ;
	
	public Account showbalance(int acc) ;
	
	public void deposit(double amt,int acc) ;
	
	public void withdraw(double res, int acc) ;	

}
