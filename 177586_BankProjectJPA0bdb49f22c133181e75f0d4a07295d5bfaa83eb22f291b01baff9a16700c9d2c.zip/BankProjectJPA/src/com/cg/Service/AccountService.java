package com.cg.Service;

import com.cg.Entity.Account;

public interface AccountService {

	public int addcustomer(Account a);
	
	public Account showbalance(int acc) ;
	
	public boolean validateCustomerName(String name);
	
	public boolean ValidateCustomerMobileno(String cid);
	
	public boolean ValidateBranch(String name);
	
	public void deposit(double amt,int acc) ;
	
	public void withdraw(double res, int acc) ;
	
	public boolean ValidateAccNo(int no);	

}
