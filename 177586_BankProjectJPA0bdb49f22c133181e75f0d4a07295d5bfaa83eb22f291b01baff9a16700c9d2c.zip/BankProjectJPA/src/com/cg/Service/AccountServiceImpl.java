package com.cg.Service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.DAO.AccountDAO;
import com.cg.DAO.AccountDAOImpl;
import com.cg.Entity.Account;

public class AccountServiceImpl implements AccountService {

	AccountDAO dao=new AccountDAOImpl();
	
	@Override
	public int addcustomer(Account a)  {
		dao.addcustomer(a);
		return 0;
	}
	
	@Override
	public Account showbalance(int acc) {
		Account a=dao.showbalance(acc);
		return a;
	}

	@Override
	public boolean validateCustomerName(String name) {
		Pattern p=Pattern.compile("[A-Z]{1}[a-z]{1,14}");
		Matcher ename=p.matcher(name);
		if(ename.matches())
		{
			return true;
		}
		return false;	
	}
	
	@Override
	public boolean ValidateCustomerMobileno(String cid) {
		Pattern p=Pattern.compile("[0-9]{10}");
		Matcher m=p.matcher(cid);
		if(m.matches())
		{
			return true;
		}	
			return false;
	}

	@Override
	public boolean ValidateBranch(String name) {
		Pattern p=Pattern.compile("[A-Z]{1}[a-z]{1,14}");
		Matcher name1=p.matcher(name);
			if(name1.matches())
		{
			return true;
		}
		return false;
	}
	
	@Override
	public void deposit(double amt,int acc)  {
		 dao.deposit(amt,acc);
		
	}
	
	@Override
	public void withdraw(double res, int acc)  {
		 dao.deposit(res,acc);
		
	}
	
	@Override
	public boolean ValidateAccNo(int no) {
		Pattern p=Pattern.compile("[0-9]{3,5}");
		String accNo=Integer.toString(no);
		Matcher m=p.matcher(accNo);
		if(m.matches())
		{
			return true;
		}
		return false;
	}
}