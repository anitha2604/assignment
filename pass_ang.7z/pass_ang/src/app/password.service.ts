import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PasswordService {

  passwordList:String[];

  constructor(private http:HttpClient) { }

  getPassword(){
    this.http.get<String[]>('http://localhost:8090/getEncryptedPassword').subscribe(data => this.passwordList = data);
  }
}
