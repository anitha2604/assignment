import { Component, OnInit } from '@angular/core';
import * as CryptoJS from 'crypto-js';  
import { PasswordService } from '../password.service';

@Component({
  selector: 'app-password-encryption',
  templateUrl: './password-encryption.component.html',
  styleUrls: ['./password-encryption.component.css']
})
export class PasswordEncryptionComponent implements OnInit {

  constructor(private passwordService:PasswordService) { }

  password:string;  
  encPassword: string = "roja";  
  decPassword:string = "roja";  
  conversionEncryptOutput: string;  
  conversionDecryptOutput:string;  

  ngOnInit() {
    this.passwordService.getPassword();
    console.log(this.passwordService.passwordList);
  }

  
  convertText() { 
      let passwordList= this.passwordService.passwordList; 
      //this.password = passwordList;
      this.conversionEncryptOutput = CryptoJS.AES.encrypt(this.password.trim(), this.encPassword.trim()).toString();  
      this.conversionDecryptOutput = CryptoJS.AES.decrypt(this.conversionEncryptOutput.trim(), this.decPassword.trim()).toString(CryptoJS.enc.Utf8);  
  }
}
