import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PasswordEncryptionComponent } from './password-encryption.component';

describe('PasswordEncryptionComponent', () => {
  let component: PasswordEncryptionComponent;
  let fixture: ComponentFixture<PasswordEncryptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PasswordEncryptionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PasswordEncryptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
