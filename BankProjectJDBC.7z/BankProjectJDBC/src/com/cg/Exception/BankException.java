package com.cg.Exception;

public class BankException extends Exception{

	public BankException(String arg0) {
		super(arg0);
		
	}
}
