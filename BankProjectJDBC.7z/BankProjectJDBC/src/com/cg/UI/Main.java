package com.cg.UI;

import java.sql.SQLException;
import java.util.Random;
import java.util.Scanner;
import com.cg.Exception.BankException;
import com.cg.Service.BankAccountService;
import com.cg.Service.AccountServiceImpl;
import com.cg.Entity.Account;
public class Main {

	static Scanner sc=null;
	static BankAccountService acc=null;
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		sc=new Scanner(System.in);
		acc=new AccountServiceImpl();
		while(true)
		{
			System.out.println("\t\tWelcome to Banking Application ");
			
			System.out.print("1.Create Account\n");
			System.out.println("2.Show Balance");
			System.out.print("3.Deposit\n");
			System.out.println("4.Withdrawal");
			System.out.print("5.Fund Transfer\n");
			System.out.println("6.Print Transaction");
			System.out.println(" enter Your Choice: ");
			int a=0;
			a=sc.nextInt();
			switch(a)
			{
			case 1:
				addcustomer();
				break;
				
			case 2:
				showbalance();
				break;
				
			case 3:
				deposit();	
				break;
				
			case 4:
				withdraw();
				break;
				
			case 5:
				fundtransfer();
				break;
				
			
			default:
				System.out.println("select from above choices only");
			}	
		}
	}
	
	public static void addcustomer()
	{
		Random ran=new Random();
		int accno=ran.nextInt(2000);
		System.out.println("Enter Customer Name");
		String name=sc.next();
		boolean resName=acc.validateCustomerName(name);
		try
		{
			if(resName==false)
			{
				throw new BankException("Invalid name");
			}
			
			{
				System.out.println("Enter Branch");
				String branch=sc.next();
				boolean resBranch=acc.ValidateBranch(branch);
				try
				{	
					if(resBranch==false)
					{
						throw new BankException("Invalid branch");
					}
					
						{
							System.out.println("Enter Mobile No");
							String mobile=sc.next();
							boolean resMob=acc.ValidateCustomerMobileno(mobile);
							try
							{
								if(resMob==false)
								{
									throw new BankException("Invalid number");
								}
									
									{
								
										
										System.out.println("Successfully account created");
										System.out.println("Name: " +name);
										System.out.println("Branch: "+branch);
										System.out.println("Mobile No: "+mobile);
										System.out.println("Account number: " +accno);
										Double balance=sc.nextDouble();
										Account a=new Account(name, branch, mobile, balance);
										acc.newcustomer(accno,a);
									}
							}
							catch(Exception e)
							{
								System.out.println("Enter the Valid number: "+e);
							}
						}
				}	
				catch (Exception e)
				{
					System.out.println("Enter the Valid Branch: "+e);	
				}			
			}	
		}
		catch (Exception e)
		{
			System.out.println("Enter the Valid name : "+e);
		}
	}
	
	
	public static void showbalance() throws ClassNotFoundException, SQLException 
	{	
		System.out.println("Enter Your Account Number: ");
		int accNo=sc.nextInt();
		
		boolean checkAcc=acc.ValidateAccNo(accNo);
		try
		{
			if(checkAcc==false)
			{
				throw new BankException("Invalid Account Number");
			}
			Account a=acc.showbalance(accNo);
			System.out.println(a.getCustomerName()+ ", Your Account Balance is: "+a.getBalance());
		}
		catch(Exception e)
		{
			System.out.println(e+"Enter the valid Account Number");
		}
	}
	

	public static void deposit() throws ClassNotFoundException, SQLException
	{
		System.out.println("Enter Your Account Number: ");
		int accNo=sc.nextInt();
		
		boolean checkAcc=acc.ValidateAccNo(accNo);
		try
		{
			if(checkAcc==false)
			{
				throw new BankException("Invalid Account Number");
			}
		
			Account a=acc.showbalance(accNo);
			double d=a.getBalance();
	
			System.out.println("Your Account Balance is: "+d);
			System.out.println("Enter the amount to be deposited: ");
			double amt=sc.nextDouble();
			double updatedAmt=a.setBalance(d+amt);
		
			System.out.println("Amount is being deposited...");
			acc.deposit(updatedAmt,accNo);
			System.out.println("Account Balance is: "+updatedAmt);
		}
		catch(Exception e)
		{
			System.out.println(e+"Enter the valid Account Number");
		}
	}
		
	
	public static void withdraw() throws ClassNotFoundException, SQLException
	{
		System.out.println("Enter Your Acct Number: ");
		int accNo=sc.nextInt();
		
		boolean checkAcc=acc.ValidateAccNo(accNo);
		try
		{
			if(checkAcc==false)
			{
				throw new BankException("Invalid Acct Number");
			}
			Account a=acc.showbalance(accNo);
			double d=a.getBalance();
		
			System.out.println("Your Acct Balance is: "+d);
			System.out.println("Enter the amount to be withdrawn: ");
			double wa=sc.nextDouble();
			try
			{
				if(d>wa)
				{
					System.out.println("Amount Withdrawing...");
					double res=a.setBalance(d-wa);
					acc.withdraw(res,accNo);
					System.out.println("Acct Balance is: "+res);
				}
				else 
				{
					throw new BankException("Insufficient Bal withdraw  amount from only  available balance");
				}
			}
			catch(Exception e)
			{
				System.out.println(e+"Enter valid amount");
			}
		}
		catch(Exception e)
		{
			System.out.println("Enter valid name"+e);
		}
	}
	
	public static void fundtransfer() throws ClassNotFoundException, SQLException
	{
		System.out.println("Enter your Account Numberfor transfering fund");
		int acc1=sc.nextInt();
		Account a1=acc.showbalance(acc1);
		
		System.out.println(a1.getBalance());
		System.out.println("Enter The Amount");
		
		double w=sc.nextDouble();
		double res=(a1.getBalance())-w;
		acc.withdraw(res, acc1);
		
		System.out.println("Amount has been debited in your account");
		System.out.println("Account Balance is: "+res);
		
		System.out.println("Enter the Account Number to receive the fund");
		int acc2=sc.nextInt();
		Account a2=acc.showbalance(acc2);
		
		System.out.println(a2.getBalance());
		double res2=(a2.getBalance())+w;
		acc.deposit(res2, acc2);
		
		System.out.println("Amount  Credited to your account" );
		System.out.println("Account Balance is: "+res2);
	}
	
	
//	public static void printtransaction() throws ClassNotFoundException, SQLException
//	{
//		fundtransfer();
//	}

}
