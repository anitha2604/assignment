package com.cg.pa.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.cg.pa.dto.Customer;
import com.cg.pa.dto.PizzaOrder;
import com.cg.pa.exceptions.PAException;

public class PizzaDAOImpl implements IPizzaDAO {

	static Map<Integer, PizzaOrder> pizzas = new HashMap<>();
	static Map<Integer, Customer> customers = new TreeMap<>();

	@Override
	public int placeOrder(Customer customer, PizzaOrder order) throws PAException {

		int orderId = (int) (Math.random() * 1000);
		int CustomerId = (int) (Math.random() * 1000);

		order.setId(orderId);
		order.setCustomerId(CustomerId);

		pizzas.put(orderId, order);
		customers.put(CustomerId, customer);

		return orderId;
	}

	@Override
	public PizzaOrder getOrderDetails(int orderId) throws PAException {

		PizzaOrder order = null;
		boolean flag = false;

		Set<Integer> set = pizzas.keySet();
		for (int id : set) {
			if (id == orderId) {
				
				PizzaOrder order2 = pizzas.get(id);
				int custId = order2.getCustomerId();
				
				Customer customer = customers.get(custId);
				
				order = pizzas.get(id);
				break;
			}
		}

		if (order == null) {
			throw new PAException("no order present with teh given id");
		}

		return order;
	}
	
	public static Customer getCustomer(int id) {
		return customers.get(id);
	}

}
