package com.cg.mob.entity;

public class Customer {
	private String cusName;
	private String cusAddress;
	private String cusCellNo;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(String cusName, String cusAddress, String cusCellNo) {
		super();
		this.cusName = cusName;
		this.cusAddress = cusAddress;
		this.cusCellNo = cusCellNo;
	}
	public String getCusName() {
		return cusName;
	}
	public void setCusName(String cusName) {
		this.cusName = cusName;
	}
	public String getCusAddress() {
		return cusAddress;
	}
	public void setCusAddress(String cusAddress) {
		this.cusAddress = cusAddress;
	}
	public String getCusCellNo() {
		return cusCellNo;
	}
	public void setCusCellNo(String cusCellNo) {
		this.cusCellNo = cusCellNo;
	}
	@Override
	public String toString() {
		return "Customer [cusName=" + cusName + ", cusAddress=" + cusAddress + ", cusCellNo=" + cusCellNo + "]";
	}
	

}
