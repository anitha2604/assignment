package com.cg.mob.ui;

import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;

import com.cg.mob.entity.Customer;
import com.cg.mob.entity.Mobile;
import com.cg.mob.exception.CustomerMobileException;
import com.cg.mob.service.CustomerMobileService;
import com.cg.mob.service.CustomerMobileServiceImp;

public class RunMain {
	static CustomerMobileService cser= new CustomerMobileServiceImp(); //creating obj to customer service through dynamic binding
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("choose your choice");
		System.out.println("select 1 to know about details of mobile");
		System.out.println("select 2 to buy mobile");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			fetchAllMobileDetails();
			
		case 2:
			purchaseMobile();
		}
		
	}
	public static void fetchAllMobileDetails() {
		HashMap<String,Mobile> run=cser.fetchAllMobileDetails();
		for(HashMap.Entry m:run.entrySet()) {
			System.out.println(m.getKey()+" "+m.getValue());
			
		}
		
	}
	public static void purchaseMobile() {
		System.out.println("select mobile to buy");
		Scanner sc=new Scanner(System.in);
		String mobile =sc.nextLine();
		Mobile mobl=cser.getMobilebyBrand(mobile);
		System.out.println(mobl);
		if(mobl==null)
		{
			System.out.println("sorry this mobile is not available");
		}
		System.out.println("enter 1 to continue or 2 to exit");
		int choice=sc.nextInt();
		if(choice==1)
		{
			Random idr=new Random();
			int idrd=idr.nextInt();
			
			System.out.println("enter customer name");
			String cusName=sc.next();
			try {
				
			if(cser.validatecusName(cusName))
			{
			while(true) {
			System.out.println("enter customer address");
			String cusAddress=sc.next();
			try {
			if(cser.validatecusAddress(cusAddress))
			{
			while(true)
			{
			System.out.println("enter customer mobile");
			String cusMobile=sc.next();
			try
			{
			if(cser.validatecusMobile(cusMobile))
			{
			while(true)
			{
			Customer cc=new Customer(cusName,cusAddress,cusMobile);
			System.out.println(cusName+ "\t"+cusAddress+"\t"+cusMobile);
			cser.addCustomer(cc);
													
		System.out.println("mobile purchase successful mobile model is"+ " "+mobile);
			System.out.println("order id is"+idrd);
			System.exit(01);
			}
										
			}
			else 
			{
			System.out.println("enter valid mobile number");
			}
			}
			catch(Exception e)
			{
									
			}
						
			}
									
			}
			else
			{
			System.out.println("enter valid  address");
			}
			}
			catch(Exception e)
			{
							
			}
			
			}
			
			
			}
			else
			{
			System.out.println("enter valid customer name");
			
			}
			
			}
			catch(Exception e)
			{
				
			}
			
			
		}
		else
		{
			System.out.println("transaction cancled");
		}
		
			
		
		
		
	}
	

}
