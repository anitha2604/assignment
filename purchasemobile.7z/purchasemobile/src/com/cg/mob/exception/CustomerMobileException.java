package com.cg.mob.exception;

public class CustomerMobileException extends Exception {

	public CustomerMobileException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	

}
