package service;

import java.sql.SQLException;
import java.util.List;

import Customer.Customers;
import Customer.MoneyTran;
import WalletException.WaExceptions;
public interface Bank_Service_Interface {
	
	public void addCustomer(Customers c) throws SQLException, ClassNotFoundException, WaExceptions;
	public Customers searchId(int id1) throws WaExceptions, ClassNotFoundException, SQLException;
	public void searchId(int id2, double amount1) throws Exception ;
	public Customers searchId1(int id8) throws WaExceptions, ClassNotFoundException, SQLException;
	public void searchfundId(int id4, double famount) throws WaExceptions, ClassNotFoundException, SQLException;
	public void searchwithdrawId(int id3, double wamount) throws  Exception;
	
}