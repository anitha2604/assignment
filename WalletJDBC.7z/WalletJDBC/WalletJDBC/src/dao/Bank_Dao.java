package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.List;



import Clients.Clients;
import Customer.Customers;
import Customer.MoneyTran;
import WalletException.WaExceptions;

public class Bank_Dao implements Bank_Dao_Interface {
	
	
	
	
//add customer
public void addCustomer(Customers c) throws WaExceptions, SQLException, ClassNotFoundException {
		
	Connection c1=Clients.connect();
	Statement stmt=c1.createStatement();
	PreparedStatement pst=c1.prepareStatement("INSERT INTO CUSTOMERS VALUES(?,?,?,?,?,?)");
	pst.setString(1,c.getName());
	pst.setString(2, c.getAddress());
	pst.setString(3, c.getPhone());
	pst.setInt(4, c.getId());
	pst.setString(5, c.getAccountno());
	pst.setDouble(6, c.getBalance());
	pst.executeUpdate();
	
}

//get balance
	public Customers searchId(int id1) throws WaExceptions, SQLException,ClassNotFoundException {
	
		Connection c2=Clients.connect();
		Statement stmt=c2.createStatement();
		ResultSet res=stmt.executeQuery("SELECT * FROM CUSTOMERS WHERE ID=' "+id1+" ' ");
		//System.out.println(res);
	
		while(res.next())
		{
			int id=res.getInt(4);
			String name=res.getString(1);
			String address=res.getString(2);
		    String phone=res.getString(3);
			double balance = res.getDouble(6);
			String accountno=res.getString(5);
			Customers c=new Customers(name,address,phone,accountno,id, balance);
			return c;
			
	}
		
		c2.commit();
		throw new WaExceptions("Invalid account number");
		
	}
//deposite money
	public void searchId(int id2, double total) throws Exception{
		Connection c=Clients.connect();
		Statement stmt=c.createStatement();
			ResultSet res1 =stmt.executeQuery("update CUSTOMERS set balance='"+total+"'where ID='"+id2+"'"); 
			 
		/*while(res1.next())
		{
			double bal =res1.getDouble(5);
			System.out.println(bal);
			//res1.updateDouble(5, amt);
			res1.updateRow();
			
	}*/
			/*while(res1.next())
			{
				int id=res1.getInt();
				String name=res1.getString(1);
				String address=res1.getString(2);
			    String phone=res1.getString(3);
				double balance =res1.getDouble(6);
				String accountno=res1.getString(5);
				Customers c12=new Customers(name,address,phone,accountno,id, balance);
				return c12;
		}
		*/
			
		c.commit();
		//throw new WaExceptions("Invalid account number");
		
		
		
		
}
//withdraw amount
	public void searchwithdrawId(int id3, double wamount) throws Exception{
		Connection c=Clients.connect();
		Statement stmt=c.createStatement();
		ResultSet res2 =stmt.executeQuery("update CUSTOMERS set balance='"+wamount+"'where ID='"+id3+"'"); 	 
				c.commit();
		
	}

	
	
//fund transfer
	public void searchfundId(int id4, double famount) throws WaExceptions, SQLException, ClassNotFoundException{
		Connection c=Clients.connect();
		Statement stmt=c.createStatement();
		ResultSet res1 =stmt.executeQuery("update CUSTOMERS set balance='"+famount+"'where ID='"+id4+"'"); 	 
				c.commit();
		
	}
	public Customers searchId1(int id8) throws WaExceptions, SQLException,ClassNotFoundException {
		
		Connection c2=Clients.connect();
		Statement stmt=c2.createStatement();
		ResultSet res=stmt.executeQuery("SELECT * FROM CUSTOMERS  WHERE ID=' "+id8+" ' ");
		//System.out.println(res);
		while(res.next())
		{
			int id=res.getInt(4);
			String name=res.getString(1);
			String address=res.getString(2);
		    String phone=res.getString(3);
			double balance = res.getDouble(6);
			String accountno=res.getString(5);
			Customers c=new Customers(name,address,phone,accountno,id, balance);
			return c;
	}
		
		
		c2.commit();
		throw new WaExceptions("Invalid account number");


}

	public List<MoneyTran> getTransaction()throws WaExceptions {
		// TODO Auto-generated method stub
		return Clients.li;
	}
}
