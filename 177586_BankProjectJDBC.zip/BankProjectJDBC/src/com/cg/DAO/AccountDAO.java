package com.cg.DAO;

import java.sql.SQLException;
import com.cg.Entity.Account;
public interface AccountDAO {

	public int addcustomer(Integer b,Account a) throws SQLException, ClassNotFoundException;
	
	public Account showbalance(int acc) throws ClassNotFoundException, SQLException;
	
	public void deposit(double amt,int acc) throws ClassNotFoundException, SQLException;
	
	public void withdraw(double res, int acc) throws ClassNotFoundException, SQLException;	
}